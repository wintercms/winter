<?php namespace Extracted\TestA;

use System\Classes\PluginBase;

class Plugin extends PluginBase
{
    public function pluginDetails()
    {
        return [
            'name' => 'Extracted Test A',
            'description' => 'Sample plugin used by unit tests.',
            'author' => 'Mix Test'
        ];
    }
}
